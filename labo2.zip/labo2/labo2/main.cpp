#include <iostream>
#include "linkedlist.h"

using namespace std;

int main()
{
    LinkedList<int> misDatos;


    return 0;
}
