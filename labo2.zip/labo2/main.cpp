//=p-Clase principal
//=b-70

#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include "linkedlist.h"//=m
#include "NodoDePartes.h"//=m

using namespace std;
int contadorLDOC = 0;

//=i
//Funcion que pide que se entrege el nombre del archivo
int funcIngresaNumeroDeArchivos()
{
    //Primero pedimos la cantidad de archivos que se desean leer.
    int iCantArchi;
    cout << "Ingrese el numero de archivos:";
    cin >> iCantArchi;
    cin.ignore();

    //Mientras no se de un numero valido seguimos pidiendo el numero de archivos
    while(cin.fail())
    {
        cout << "Error! Ingresa un numero de archivos:";
        cin.clear();
        cin.ignore(256, '\n');
        cin >> iCantArchi;
        cin.ignore();
    }
    //Regresamos el numero de archivos
    return iCantArchi;
}


//=i
//Funcion para validar que el archivo que se solicito abrir exista.
string funcValidadorDeNombres(string sNom)
{
    ifstream arch(sNom.c_str());
    //Aqui verificamos si el archivo existe o no
    while(!arch.good())
    {
        //Ci no existe pedimos se ingrese otra vez el nombre
        cout<<"Archivo inexistente! Ingrese otro nombre:";
        getline(cin, sNom);
        ifstream arch(sNom.c_str());

        //Si encutra el nombre del archivo lo refresa.
        if(arch.good())
        {
            return sNom;
        }
    }
    //Regresa el nombre del archivo que encontro
    return sNom;
}

//=i
//Funcion propia para en base a un string poder obtener el itn correspondiente.
long stringToInt(string x)
{
    long intege;
    intege = 0;

    //En el for usamos los charas ascii de cada uno de los chars para obtener el valro numerico por medio de uan resta.
    for(int i = 0 ; i<x.length() ; ++i)
    {
        if(x[i] >= '0' && x[i]<= '9')
        {
            intege = intege * 10 + (x[i] - '0');
        }
    }

    return intege;
}

//=i
//Funcion para ver si la linea consite de puros espacios
//Indicamos que queremos que regrese el valor de la bandera
void spaceChecker(string sLinea, bool &bEspacio, int &contador)
{
    //Recorremos la linea posicion por posicion, y mientras ea espacio o no haya encontrado ya una letra sigue recorriendola
    for(unsigned int i = 0; i < sLinea.length() && bEspacio; i++)//=m
    {
        //Si es espacio marcamos que aun no ha encontrado letras con la variable bEspacio
        if((isspace(sLinea[i]) || sLinea[i] == '{' && !isspace(sLinea[i+1]) || sLinea[i] == '}'&& !isspace(sLinea[i+1])) && bEspacio) //=m
        {
            bEspacio = true;//=m
        }
        //Si encuentra una letra marcamos la variable bEspacio
        else
        {
            bEspacio = false;//=m
            //marcamos la posicion como inicial.
            contador = i;
            contadorLDOC++;
        }
    }
}

//=i
//Funcion para checar las condiciones que se presentan en la linea que ya se sabe es algo
void conditionManager(string sLinea, bool &bIsComment, bool &bIsMComment, bool &bIsString, bool &bIsTag, bool &bIsText, bool bEspacio, int contador, size_t found)
{
    //Si no es espacio haremos esta funcion
    //=d-2

    //Buscamos elimianr primero los comentarios sencillos para que no haya conflicto con los tags
    if(sLinea.substr(contador,3) != "//=" && sLinea.substr(contador,2) == "//")
    {
        bIsComment = true;
        bIsMComment = false;
        bIsText = false;
        bIsTag = false;
        return;
    }
    else
    {
        //Si no se dio el caso de que fuera un comentario vemos si en la posicion inicial se presenta
        //que sea un tag.
        if(sLinea.substr(contador,3) == "//=" )
        {
            bIsTag = true;
            bIsMComment = false;
            bIsComment = false;
            bIsText = false;
            return;
        }
        else
        {
            //Ahora buscamos quitar comentarios multiples, nuevamente usamos la funcion subtr para ver si lo primero es en efecto un comentario multiple.
            if(sLinea.substr(contador,2) == "/*")
            {
                bIsMComment = true;
                bIsComment = false;
                bIsText = false;
                bIsTag = false;
                return;
            }
            else
            {
                //Si no es coemntario y no es espacio entonces es una liena que nos interesa
                //Recorremos para ver si el tag esta o no dentro de un string


                //Buscamos si esta la tag =m y si esta buscamos que sea valida.
                found = sLinea.find("//=m")+3;
                if(found != string::npos)
                {
                    if(found == sLinea.length()-1)
                        bIsTag = true;
                    else
                    {
                        bIsTag = true;

                        for(int x = found+1; x < sLinea.length() && bIsTag; x++)
                            if(isspace(sLinea[x]))
                            {
                                bIsTag = true;
                                bIsText = true;
                                return;
                            }
                            else
                                bIsTag = false;
                    }
                }

                //Buscamos asegurarnos de que lo que se esta tomando no ees una linea sencilla con un tag
                //Cada if sige la siguiente estructura, si no lo encuntra checa la siguiente tag, si no encontro ninguna, es texto, si si checa que cada tag sea lo primero y unico de la linea.
                found = sLinea.find("//=p");
                if(found == string::npos)
                {
                    found = sLinea.find("//=b");
                    if(found == string::npos)
                    {
                        found = sLinea.find("//=i");
                        if(found == string::npos)
                        {
                            found = sLinea.find("//=d");
                            if(found == string::npos)
                            {
                                bIsText = true;
                            }
                            else
                            {
                                if(contador == found && sLinea[contador+4] == '-')
                                    bIsTag = true;
                            }
                        }
                        else
                        {
                            if(contador == found)
                                bIsTag = true;
                            return;
                        }
                    }
                    else
                    {
                        if(contador == found && sLinea[contador+4] == '-')
                            bIsTag = true;
                    }
                }
                else
                {
                    if(contador == found && sLinea[contador+4] == '-')
                    {
                        bIsTag = true;
                    }
                }

                if(bIsTag)
                {
                    if(sLinea[contador-1] == '\"')
                    {
                        bIsTag = false;
                    }
                }
            }
        }
    }
}

int main()
{
    //Variable para el manejo de los archivos de texto que se usaran.
    ifstream ifArchivo;

    //Variable para la linea que se va a procesar. Variable para almacenar el nombre del archivo.
    string sLinea = ""; //=m
    string sPlaceHolder = "";

    //Variable para tener la cantidad de archivos.
    int iCantidadArchivos = 0;

    //Variable para ver donde empieza el texto.
    int contador = 0; //=m
    int iAux = 0;//=m

    //Variable auxiliar de nodo
    NodoDePartes nAux; //=m

    //Lista para nodos auxiliares
    linkedlist listaBase; //=m

    //Lista para partes nuevas
    linkedlist listaNuevas;

    //Lista para las partes reusadas
    linkedlist listaReusadas;

    //Obtenemos el numero de archivos
    iCantidadArchivos = funcIngresaNumeroDeArchivos();

    //Variables booleanas para control
    //Variable para romper ciclos si encuentra una letra
    bool bEspacio = true;//=m
    bool bIsComment = false;
    bool bIsMComment = false;
    bool bIsText = false;
    bool bIsTag = false;
    bool bIsString = false;

    //Variable de tamanio para marcar donde se encuentra cada elemento.
    size_t found;
    char x;

    cout << "Ingresa el nombre que quieres que tenag el archivo de salida(incluye al terminacion)" << endl;
    getline(cin,sPlaceHolder);

    //Creamos el archivo que se nos pidio.
    ofstream ox (sPlaceHolder.c_str());

    sPlaceHolder = "";

    //En el for nos basamos en el numero de archivos que se deben procesar.
    for (int i = 0; i < iCantidadArchivos ; i++)
    {
        cout << "Ingresa el nombre del archivo" << endl;
        getline(cin, sPlaceHolder);

        //Validamos el nombre del archivo
        sPlaceHolder = funcValidadorDeNombres(sPlaceHolder);

        //Lo abrimos, pero como es string usamos la funcion .c_str()
        ifArchivo.open(sPlaceHolder.c_str());

        //Obtenemos la primera liena del archivo y seguimos procesando hatsa llegar a la utima la cual tambien se procesa con el mismo while
        while(getline(ifArchivo, sLinea))
        {
            //Usamos la funcion  que checa si es espacio o no para proseguir.
            spaceChecker(sLinea, bEspacio, contador);
            //Si fue puro espacio lo marcamos como tal. Pero si no, hacemos el else
            if(bEspacio)
            {
                bEspacio = true;
                bIsComment = false;
                bIsMComment = false;
                bIsText = false;
                bIsTag = false;
                bIsString = false;
            }
            //El else lo que hace es que checa que condiciones cumple la linea.
            else
            {
                conditionManager(sLinea, bIsComment, bIsMComment, bIsString, bIsTag, bIsText, bEspacio, contador, found);
            }

            //En base a las condiciones que se cmplen dadas por la funcion conditionManager hacemos lo correspondiente

            //Si es comentario restmos uan LDOC y no hacemos nada mas.
            if (bIsComment)
            {
                contadorLDOC--;
            }

            //Si fue un Comentario Muliple leemos hasta encontrar el final del mismo e ignoramos cada LDOC.
            if(bIsMComment)
            {
                do
                {
                    found = sLinea.find("*/");

                    if (found == string::npos)
                    {
                        contadorLDOC--;
                        getline(ifArchivo, sLinea);
                    }
                    else
                    {
                        bIsMComment = false;
                        getline(ifArchivo, sLinea);
                    }
                }
                while(bIsMComment);
            }

            //Si fue un tag, vemos que tag fue.
            if(bIsTag)
            {
                found = sLinea.find("//=");
                if(found != string::npos && sLinea[found-2] != '(')
                {
                    //Ubico el char que identifica la tag
                    //En todos los tag debo ver si la parte ya tiene nombre, lo que significa que estoy dentro de una
                    sPlaceHolder = sLinea.substr(found+3,1);
                    x = sPlaceHolder[0];
                    switch(x)
                    {
                    case 'p':
                        //Si fue p y no haia nada, seteo los valores a iniciales.
                        if(nAux.getsP()== "")
                        {
                            nAux.setsP(sLinea.substr(found+5));
                            nAux.setiA(0);
                            nAux.setiB(0);
                            nAux.setiD(0);
                            nAux.setiI(0);
                            nAux.setiM(0);
                            nAux.setiT(0);
                        }
                        //Si ya habia algo almaceno el nodo auxiliar en la lita correspondiente.
                        else
                        {
                            iAux = nAux.getiT() - nAux.getiB() + nAux.getiD();
                            nAux.setiA(iAux);

                            if(nAux.getiB()>0 && (nAux.getiM()>0 || nAux.getiD()>0 || nAux.getiA()>0))
                                listaBase.add(nAux);
                            else if (nAux.getiB() == 0 && nAux.getiM() == 0 && nAux.getiD() == 0 && nAux.getiA()>0)
                                listaNuevas.add(nAux);
                            else
                                listaReusadas.add(nAux);

                            nAux.setsP("");
                            nAux.setiA(0);
                            nAux.setiB(0);
                            nAux.setiD(0);
                            nAux.setiI(0);
                            nAux.setiM(0);
                            nAux.setiT(0);

                            nAux.setsP(sLinea.substr(found+5));
                        }
                        contadorLDOC--;
                        break;
                    case 'b':
                        //Si el tag fue b pongo las lineas base.
                        if(nAux.getsP()!="")
                        {
                            iAux = nAux.getiB();
                            sPlaceHolder =sLinea.substr(found+5);
                            iAux += stringToInt(sPlaceHolder);
                            nAux.setiB(iAux);
                            contadorLDOC--;
                        }
                        break;
                    case 'd':
                        //Si el tag fue d sumo las lienas deleted
                        if(nAux.getsP()!="")
                        {
                            iAux = nAux.getiD();
                            sPlaceHolder = sLinea.substr(found+5);
                            iAux += stringToInt(sPlaceHolder);
                            nAux.setiD(iAux);
                            contadorLDOC--;
                        }
                        break;
                    case 'm':
                        //Si el tag fue m sumo uno a las lienas modificadas.
                        if(nAux.getsP()!="")
                        {
                            iAux = nAux.getiM();
                            iAux++;
                            nAux.setiM(iAux);
                        }
                        break;
                    case 'i':
                         //Si el tag fue i sumo uno a los items
                        if(nAux.getsP()!="")
                        {
                            iAux = nAux.getiI();
                            iAux++;
                            nAux.setiI(iAux);
                            //        getline(ifArchivo, sLinea);
                            contadorLDOC--;
                        }
                        break;
                    }
                }
            }

            //Si fue texto sumamos uno a las lienas de codigo
            if(nAux.getsP()!="")
            {
                if(bIsText)
                {
                    nAux.iT++;
                    bIsText = false;
                }
            }
            //Formateamos las variables de control
            bEspacio = true; //=m
            bIsComment = false;
            bIsMComment = false;
            bIsText = false;
            bIsTag = false;
            bIsString = false;
        }

        //Ultimo set de isntruccioens pra agregar el nodo, para cuando ya no se encuentre un tag de p y sea el fin del archivo.
        if(nAux.getsP()!="")
        {
            iAux = nAux.getiT() - nAux.getiB() + nAux.getiD();
            nAux.setiA(iAux);

            if(nAux.getiB()>0 && (nAux.getiM()>0 || nAux.getiD()>0 || nAux.getiA()>0))
                listaBase.add(nAux);
            else if (nAux.getiB() == 0 && nAux.getiM() == 0 && nAux.getiD() == 0 && nAux.getiA()>0)
                listaNuevas.add(nAux);
            else
                listaReusadas.add(nAux);

            nAux.setsP("");
            nAux.setiA(0);
            nAux.setiB(0);
            nAux.setiD(0);
            nAux.setiI(0);
            nAux.setiM(0);
            nAux.setiT(0);
        }

        //Al terminar de procesar el archivo se cierra.
        ifArchivo.close();

        //=d-8
    }

    //=d-3

    cout << "Partes Base: \n";
    listaBase.print();
    cout << "-----------------------------------------------------\n";

    cout << "Partes Nuevas: \n";
    listaNuevas.printNew();
    cout << "-----------------------------------------------------\n";

    cout << "Partes Reusadas: \n";
    listaReusadas.printReused();
    cout << "-----------------------------------------------------\n";

    cout << "Total de lineas de codigo = " << contadorLDOC<<endl;

    if(ox.is_open())
    {
        //aL ARCHIVO LO ESCRIBIMOS AQUI
        ox << "Partes Base: \n";
        listaBase.printToFile(ox);
        ox << "-----------------------------------------------------\n";

        ox << "Partes Nuevas: \n";
        listaNuevas.printToFileNew(ox);
        ox << "-----------------------------------------------------\n";

        ox << "Partes Reusadas: \n";
        listaReusadas.printToFileReused(ox);
        ox << "-----------------------------------------------------\n";

        ox << "Total de lineas de codigo = " << contadorLDOC<<endl;

        ox.close();
    }

    return 0;
}
