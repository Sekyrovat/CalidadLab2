//=p-Nodo
#ifndef NodoDePartes_H
#define NodoDePartes_H

#include <iostream>
using namespace std;
class NodoDePartes
{
public:
    //Constructor sin parametros
    NodoDePartes ();
    //Constructor con parametros pero in next
    NodoDePartes (string sP1, int iT1, int iI1, int iB1, int iD1, int iM1, int iA1);
    //Constructor con parametros con next
    NodoDePartes (string sP1, int iT1, int iI1, int iB1, int iD1, int iM1, int iA1, NodoDePartes* next1);

    //Getters de cada variable de forma individual
    string getsP();
    int getiT();
    int getiI();
    int getiB();
    int getiD();
    int getiM();
    int getiA();


    //Setters para cada variable
    void setsP(string sP1);
    void setiT(int iT1);
    void setiI(int iI1);
    void setiB(int iB1);
    void setiD(int iD1);
    void setiM(int iM1);
    void setiA(int iA1);


    //Metodo para obtener el siguiente nodo
    NodoDePartes* getNext();


//=i
    //Metodo para setear el siguiente nodo
    void setNext(NodoDePartes* newNode)
    {
        next = newNode;
    }

    //Se decidio poner todas ,as variables como publicas para que se peudan accesar de forma mas sencilla.
    //Variable donde se almacenara el tipo de parte: 1 = Base, 2 = Nueva, 3 = Reusada
    string sP;
    //Variabel para almacenar las lineas de codigo totales de cada parte
    int iT;
    //Variable para  almacenar el numero total de items
    int iI;
    //Variable para almacenar el numero de lineas base
    int iB;
    //Variable para almacenar las lineas borradas
    int iD;
    //Variable para almacenar las lineas modificadas
    int iM;
    //Variable donde se calculaa las lineas agregadas
    int iA;


    //Declaracion de las variables que tendra el nodo, donde cada nodo evaluara a una parte.
private:

    //Apuntador al siguiente nodo
    NodoDePartes *next;
};

//=i
//Constructor vacio
NodoDePartes::NodoDePartes()
{
    sP = "";
    iT = 0;
    iI = 0;
    iB = 0;
    iD = 0;
    iM = 0;
    iA = 0;
    next = NULL;
}

//=i
//Constructor con parametros pero sin next
NodoDePartes::NodoDePartes(string sP1, int iT1, int iI1, int iB1, int iD1, int iM1, int iA1)
{
    sP = sP1;
    iT = iT1;
    iI = iI1;
    iB = iB1;
    iD = iD1;
    iM = iM1;
    iA = iA1;
    next = NULL;
}

//=i
//Constructor con parametros y next
NodoDePartes::NodoDePartes(string sP1, int iT1, int iI1, int iB1, int iD1, int iM1, int iA1, NodoDePartes* next1)
{
    sP = sP1;
    iT = iT1;
    iI = iI1;
    iB = iB1;
    iD = iD1;
    iM = iM1;
    iA = iA1;
    next = next1;
}

//Todos los getter que se necesitan
//Obtener el valor de sP
string  NodoDePartes::getsP()
{
    return sP;
}
int NodoDePartes::getiT()
{
    return iT;
}
int NodoDePartes::getiI()
{
    return iI;
}
int NodoDePartes::getiB()
{
    return iB;
}
int NodoDePartes::getiD()
{
    return iD;
}
int NodoDePartes::getiM()
{
    return iM;
}
int NodoDePartes::getiA()
{
    return iA;
}

//Setters para cada variable
void NodoDePartes::setsP(string  sP1)
{
    sP = sP1;
}
void NodoDePartes::setiT(int iT1)
{
    iT = iT1;
}
void NodoDePartes::setiI(int iI1)
{
    iI = iI1;
}
void NodoDePartes::setiB(int iB1)
{
    iB = iB1;
}
void NodoDePartes::setiD(int iD1)
{
    iD = iD1;
}
void NodoDePartes::setiM(int iM1)
{
    iM = iM1;
}
void NodoDePartes::setiA(int iA1)
{
    iA = iA1;
}

//=i
//Metodo para obtener el siguiente nodo
NodoDePartes* NodoDePartes::getNext()
{
    return next;
}

#endif
