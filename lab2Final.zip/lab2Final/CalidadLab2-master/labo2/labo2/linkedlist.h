//=p-LinkedList
#ifndef linkedlist_h
#define linkedlist_h

#include "NodoDePartes.h"
using namespace std;
class linkedlist
{
private:
    //Apuntador al primer elemento de la lista
    NodoDePartes* head;
    //Variable de control para ver el tamanio de la lista
    int length;
    //Variable para ver si hay elementos en la lista
    bool isEmpty();
    //Funcio nde destructor
    void borra();

public:
    //Constructor Vacio
    linkedlist();
    //Destructor
    ~linkedlist();
    //Funcion para obtener el tamanio
    int getlength();

    //Funcion para agregar un nodo al inicio
    void addFirst(NodoDePartes nAuxiliar);

    //Funcion para agregar continuamente en lo que se recorre la lista.
    void add(NodoDePartes nodex);
    //Funcion para imprimir que llama a que se imprima cada nodo
    void print();
    void printNew();
    void printReused();

    void printToFile(ofstream &x);
    void printToFileNew(ofstream &x);
    void printToFileReused(ofstream &x);
    //Funcion para obtener el HEAD de la lista
    NodoDePartes* gethead();

};

//=i
//Funcion de inicializacion de una linkedlist vacia
linkedlist::linkedlist()
{
    //Se establece que no se apunta a un valor nulo para estar vacio
    head = NULL;
    //No tiene tamanio
    length = 0;
}

//=i
//Funcion para obtener el tamanio.
int linkedlist::getlength()
{
    //Se regresa el taamnio
    return this->length;
}

//=i
bool linkedlist::isEmpty()
{
    return (head == NULL);
}

//=i
//Funcion para borrar toda la lista
void linkedlist::borra()
{
    //Se crea un nodo auxiliar que recorre toda la lista hasta elimanr todo
    NodoDePartes *aux = head;
    while (head != NULL)
    {
        head = head->getNext();
        delete aux;
        aux = head;
    }
}

//=i
//Destructor de la Linked List
linkedlist::~linkedlist()
{
    borra();
}

//=i
//Esta funcion es usada para agregar el primer nodo a la lista
void linkedlist::addFirst(NodoDePartes node)
{
    head = new NodoDePartes(node.sP, node.iT, node.iI, node.iB, node.iD, node.iM, node.iA);
    length++;
}

//=i
//Agrega un elemento al topo de la lista
void linkedlist::add(NodoDePartes nodex)
{
    //Verificamos si esta vacia
    if (this->isEmpty())
    {
        //Si si agregamos el nodo como primer elemento
        this->addFirst(nodex);
    }
    else
    {
        //Vaiable de control para ver si ya existia el nodo
        bool bFlag = true;
        NodoDePartes *aux = head;

        while (aux->getNext() != NULL && bFlag)
        {
            //En el ciclo recorremos la lista
            //En el if vemos si ya existe
            if (aux->getsP() == nodex.getsP())
            {
                bFlag = false;
            }
            //Si no lo encuentra la vatiable de control se mantiene como true y recorre mas la lista
            if (bFlag)
                aux = aux->getNext();
        }

        //Se verifica si se debe agregar como un nodo nuevo.
        if (bFlag)
            aux->setNext(new NodoDePartes(nodex.getsP(), nodex.getiT(), nodex.getiI(), nodex.getiB(), nodex.getiD(), nodex.getiM(), nodex.getiA()));
        //En caso de que no, significa que ya existe, solo sumamos valores.
        else
        {
            aux->setiA(aux->getiA() + nodex.getiA());
            aux->setiB(aux->getiB() + nodex.getiB());
            aux->setiD(aux->getiD() + nodex.getiD());
            aux->setiI(aux->getiI() + nodex.getiI());
            aux->setiM(aux->getiM() + nodex.getiM());
            aux->setiT(aux->getiT() + nodex.getiT());
        }
        length++;
    }
}

//=i
//Funcion de utilidad para imprimir la lista
void linkedlist::print()
{
    NodoDePartes *aux = head;
    while (aux != NULL)
    {
        cout << aux->getsP() << "\t" << "T = " << aux->getiT() << "\t" << "I = " << aux->getiI() << "\t" << "B = " << aux->getiB() << "\t" << "D = " << aux->getiD() << "\t" << "M = " << aux->getiM() << "\t" << "A = " << aux->getiA() << endl;
        aux = aux->getNext();
    }
    cout << endl;
}

//=i
void linkedlist::printNew()
{
    NodoDePartes *aux = head;
    while (aux != NULL)
    {
        cout << aux->getsP() << ":\t" << "T = " << aux->getiT() << "\t" << "I = " << aux->getiI() << endl;
        aux = aux->getNext();
    }
    cout << endl;
}

//=i
void linkedlist::printReused()
{
    NodoDePartes *aux = head;
    while (aux != NULL)
    {
        cout << aux->getsP() << ":\t" << "T = " << aux->getiT() << "\t" << "I = " << aux->getiI() << "\t" << "B = " << aux->getiB() << endl;
        aux = aux->getNext();
    }
    cout << endl;
}

//=i
//Funcion que hara lo mismo que la superior pero a un archivo de texto
void linkedlist::printToFile(ofstream &x)
{
    NodoDePartes *aux = head;
    while (aux != NULL)
    {
        x << aux->getsP() << "\t" << "T = " << aux->getiT() << "\t" << "I = " << aux->getiI() << "\t" << "B = " << aux->getiB() << "\t" << "D = " << aux->getiD() << "\t" << "M = " << aux->getiM() << "\t" << "A = " << aux->getiA() << endl;
        aux = aux->getNext();
    }
    x << endl;
}

void linkedlist::printToFileNew(ofstream &x)
{
    NodoDePartes *aux = head;
    while (aux != NULL)
    {
        x << aux->getsP() << ":\t" << "T = " << aux->getiT() << "\t" << "I = " << aux->getiI() << endl;
        aux = aux->getNext();
    }
    x << endl;
}

void linkedlist::printToFileReused(ofstream &x)
{
    NodoDePartes *aux = head;
    while (aux != NULL)
    {
        x << aux->getsP() << ":\t" << "T = " << aux->getiT() << "\t" << "I = " << aux->getiI() << "\t" << "B = " << aux->getiB() << endl;
        aux = aux->getNext();
    }
    x << endl;
}
#endif
