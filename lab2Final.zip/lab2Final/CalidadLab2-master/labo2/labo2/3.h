//=p-Nodo
//=b-94
#ifndef NodoDePartes_H
#define NodoDePartes_H

#include <iostream>
using namespace std;
class NodoDePartes
{
public:
    //Constructor sin parametros
    NodoDePartes ();
    //Constructor con parametros pero in next
    NodoDePartes (double dXT, double dYT);//=m
    //Constructor con parametros con next
    NodoDePartes (double dXT, double dYT, NodoDePartes* next1);//=m
    //=d-21
    //Metodo para obtener el siguiente nodo
    NodoDePartes* getNext();

    double getDX();
    double getDY();

    void setDX(double dXTemp);
    void setDY(double dYTemp);
    //=i
    //Metodo para setear el siguiente nodo
    void setNext(NodoDePartes* newNode)
    {
        next = newNode;
    }

    //Declaracion de las variables que tendra el nodo, donde cada nodo evaluara a una parte.
private:
    //Apuntador al siguiente nodo
    NodoDePartes *next;
    double dX;
    double dY;
};


//=d-7
//=i
//Constructor vacio
NodoDePartes::NodoDePartes()
{
    dX = 0.0;
    dY = 0.0;
    next = NULL;
}

//=d-7
//=i
//Constructor con parametros pero sin next
NodoDePartes::NodoDePartes(double dXT, double dYT) //=m
{
    dX = dXT;
    dY = dYT;
    next = NULL;
}

//=d-7
//=i
//Constructor con parametros y next
NodoDePartes::NodoDePartes(double dXT, double dYT, NodoDePartes* next1)//=m
{
    dX = dXT;
    dY = dYT;
    next = next1;
}


//=d-14
double NodoDePartes::getDX()
{
    return dX;
}
double NodoDePartes::getDY()
{
    return dY;
}

//=d-14
void NodoDePartes::setDX(double dXTemp)
{
    dX = dXTemp;
}

void NodoDePartes::setDY(double dYTemp)
{
    dY = dYTemp;
}

//=i
//Metodo para obtener el siguiente nodo
NodoDePartes* NodoDePartes::getNext()
{
    return next;
}

#endif
