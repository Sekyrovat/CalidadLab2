//=p-Clase principal
//=b-271

#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <iomanip>
#include <math.h> //=m
#include <string.h>
#include <stdlib.h>     /* atof */
#include "linkedlist.h"
#include "NodoDePartes.h"

using namespace std;
int tam = 0; //=m

//=i
//Funcion que pide que se entrege el nombre del archivo
int funcIngresaNumeroDeArchivos()
{
    //Primero pedimos la cantidad de archivos que se desean leer.
    int iCantArchi;
    cout << "Ingrese el numero de archivos:";
    cin >> iCantArchi;
    cin.ignore();

    //Mientras no se de un numero valido seguimos pidiendo el numero de archivos
    while(cin.fail())
    {
        cout << "Error! Ingresa un numero de archivos:";
        cin.clear();
        cin.ignore(256, '\n');
        cin >> iCantArchi;
        cin.ignore();
    }
    //Regresamos el numero de archivos
    return iCantArchi;
}


//=i
//Funcion para validar que el archivo que se solicito abrir exista.
string funcValidadorDeNombres(string sNom)
{
    ifstream arch(sNom.c_str());
    //Aqui verificamos si el archivo existe o no
    while(!arch.good())
    {
        //Ci no existe pedimos se ingrese otra vez el nombre
        cout<<"Archivo inexistente! Ingrese otro nombre:";
        getline(cin, sNom);
        ifstream arch(sNom.c_str());

        //Si encutra el nombre del archivo lo refresa.
        if(arch.good())
        {
            return sNom;
        }
    }
    //Regresa el nombre del archivo que encontro
    return sNom;
}

//=d-18
//=d-59

//=i
void Sumatorias(linkedlist ParLista, double &SumX, double &SumY, double &SumX2, double &SumY2, double &SumXPorY)
{
    double ValX = 0.0;
    double ValY = 0.0;
    NodoDePartes *nodo;

    for(int i = 0; i < tam; i++)
    {
        nodo = ParLista.getNode(i);

        ValX = nodo->getDX();
        ValY = nodo->getDY();

        SumX += ValX;
        SumY += ValY;
        SumX2 += pow(ValX,2);
        SumY2 += pow(ValY,2);
        SumXPorY += ValX*ValY;
    }
}

//=i
void Promedios(double SumX, double &XProm, double SumY, double &YProm)
{
    XProm = SumX/tam;
    YProm = SumY/tam;
}

//=i
void ObtenVals(double SumX, double SumY, double SumX2, double SumY2, double SumXPorY, double XProm, double YProm, double &b1, double &b0, float &r, float &r2)
{
    b1 = (SumXPorY - (tam * XProm * YProm))/(SumX2 - (tam * pow(XProm,2)));
    b0 = YProm - (b1 * XProm);
    r = ((tam * SumXPorY) - (SumX * SumY)) / sqrt(((tam * SumX2) - pow(SumX,2)) * ((tam * SumY2) - pow(SumY,2)));
    r2 = pow(r,2);
}

//=i
void Calcula(double b0, double b1, double xk, double &yk)
{
    yk = b0 + (b1*xk);
}

//=i
void Imprime(double xk, float r, float r2, double b0, double b1, double yk)
{
    cout << "N= " << tam << endl;
    cout << "Xk = " << setprecision(5) << fixed << xk << endl;
    cout << "r = " << setprecision(5) << fixed << r << endl;
    cout << "r2 = " << setprecision(5) << fixed << r2 << endl;
    cout << "b0 = " << setprecision(5) << fixed << b0 << endl;
    cout << "b1 = " << setprecision(5) << fixed << b1 << endl;
    cout << "Yk = " << setprecision(5) << fixed << yk << endl;
}

int main()
{
    //Variable para el manejo de los archivos de texto que se usaran.
    ifstream ifArchivo;

    //Variable para la linea que se va a procesar. Variable para almacenar el nombre del archivo.
    string sLinea = ""; //=m
    string sPlaceHolder = "";

    //=d-1
    //=d-2

    //Variable auxiliar de nodo
    NodoDePartes Nodo; //=m
    //Lista para nodos auxiliares
    linkedlist ParLista; //=m

    //=d-1

    int iCantidadArchivos = 0;


    double SumX = 0.0;
    double SumY = 0.0;
    double SumX2 = 0.0;
    double SumY2 = 0.0;
    double SumXPorY = 0.0;

    double XProm = 0.0;
    double YProm = 0.0;

    double b1 = 0.0;
    double b0 = 0.0;
    float r = 0.0;
    float r2 = 0.0;

    double xk = 0.0;
    double yk = 0.0;

    //=d-6

    //Variable de tamanio para marcar donde se encuentra cada elemento.
    size_t found;
    char x;

    //=d-5

    cout << "Ingresa el nombre del archivo" << endl;
    getline(cin, sPlaceHolder);

    //Validamos el nombre del archivo
    //sPlaceHolder = funcValidadorDeNombres(sPlaceHolder);

    //Lo abrimos, pero como es string usamos la funcion .c_str()
    ifArchivo.open(sPlaceHolder.c_str());

    //Obtenemos la primera liena del archivo y seguimos procesando hatsa llegar a la utima la cual tambien se procesa con el mismo while
    getline(ifArchivo,sLinea);
    xk = atof(sLinea.c_str());

    while(getline(ifArchivo, sLinea))
    {
        //=d-114
        found = sLinea.find(",");

        Nodo.setDX(atof(sLinea.substr(0,found).c_str()));
        Nodo.setDY(atof(sLinea.substr(found+1).c_str()));
        ParLista.add(Nodo);
    }
        //Al terminar de procesar el archivo se cierra.
    ifArchivo.close();

    tam = ParLista.getlength();

    Sumatorias(ParLista, SumX, SumY, SumX2, SumY2, SumXPorY);

    Promedios(SumX, XProm, SumY, YProm);

    ObtenVals(SumX, SumY, SumX2, SumY2, SumXPorY, XProm, YProm, b1, b0, r, r2);

    Calcula(b0, b1, xk,  yk);

    Imprime(xk, r, r2, b0, b1, yk);

    //=d-33

    return 0;
}
